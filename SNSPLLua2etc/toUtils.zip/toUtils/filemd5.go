package toutils

import (
	"crypto/md5"
	"encoding/hex"
	"fmt"
	"io"
	"os"
)

func Md5File(filePath string) (string, error) {
	file, err := os.Open(filePath)
	if err != nil {
		return "", err
	}
	defer file.Close()

	hash := md5.New()
	if _, err := io.Copy(hash, file); err != nil {
		return "", err
	}

	return hex.EncodeToString(hash.Sum(nil)), nil // 202cb962ac59075b964b07152d234b70
}

// WriteFile 将指定内容写入到指定路径的文件中。
// 参数:
//   - filePath: 要写入内容的文件路径。
//   - content: 要写入文件的内容。
//
// 返回值:
//   - error: 如果在打开文件或写入文件过程中发生错误，则返回相应的错误信息。
func WriteFile(filePath string, content []byte) error {
	file, err := os.Create(filePath)
	if err != nil {
		return err
	}
	defer file.Close()

	_, err = file.Write(content)
	if err != nil {
		return err
	}
	fmt.Println("写入成功")
	return err
}
