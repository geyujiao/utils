package toutils

import (
	"testing"
)

func TestHeaderList(t *testing.T) {

	// LogListV2("access-write/accessL1.txt", "access-write/result/accessL1.txt", "access_by_lua_file")
	// LogListV2("access-write/accessL2.txt", "access-write/result/accessL2.txt", "access_by_lua_file")
	// LogListV2("access-write/accessL3.txt", "access-write/result/accessL3.txt", "access_by_lua_file")

	// LogListV2("access-write/rewriteL1.txt", "access-write/result/rewriteL1.txt", "rewrite_by_lua_file")
	// LogListV2("access-write/rewriteL2.txt", "access-write/result/rewriteL2.txt", "rewrite_by_lua_file")
	// LogListV2("access-write/rewriteL3.txt", "access-write/result/rewriteL3.txt", "rewrite_by_lua_file")

	// // LogList("L2-logfile.txt")
	// UserAgentList("user_agent.txt", "ua_result.txt")
	// UserAgentList("cookie.txt", "cookie_result.txt")
	// UserAgentList("referer.txt", "referer_result.txt")
	// UserAgentList("uri.txt", "uri_result.txt")

	// result := LogList("log.txt")
	// bytes, _ := json.Marshal(result)
	// print(string(bytes))

}
