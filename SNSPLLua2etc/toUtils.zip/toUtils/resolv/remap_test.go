package resolve

import (
	"testing"
)

func TestNoResolveList(t *testing.T) {

	// result := NoResolveList("remapL1.config")
	// bytes, _ := json.Marshal(result)
	// println(string(bytes))

	result := NoResolveListL2("remapL2.config")
	list := make([]string, 0)
	for k, _ := range result {
		list = append(list, k)
	}
	WriterFile("remapL2-result.txt", list)
}

// L1
// live.gj.miguvideo.com
// yy.migu.cmvideo.cn
// noResolve :={
//     "map http://cdn-traffic.cdn.10086.cn http://test.dcnd.com @plugin=resolv.so @pparam=39.135.88.215:8080": 1,
//     "map http://edu.sd.chinamobile.com http://edu.sd.chinamobile.com @plugin=resolv.so @pparam=120.221.159.55:80 @plugin=tslua.so @pparam=/etc/trafficserver/lua/edu.sd.chinamobile.com.lua @plugin=background_fetch.so": 1,
//     "map http://eduapp.sd.chinamobile.com:443 http://eduapp.sd.chinamobile.com @plugin=resolv.so @pparam=120.221.159.57:80 @plugin=tslua.so @pparam=/etc/trafficserver/lua/eduapp.sd.chinamobile.com.lua @plugin=background_fetch.so": 1,
//     "map http://edugl.sd.chinamobile.com http://edugl.sd.chinamobile.com @plugin=resolv.so @pparam=120.221.159.56:80 @plugin=tslua.so @pparam=/etc/trafficserver/lua/edugl.sd.chinamobile.com.lua @plugin=background_fetch.so": 1,
//     "map http://fcns.komect.com https://fcns.komect.com:443 @plugin=resolv.so @pparam=7ffdd12f8477754d.waf.komect.com:443 @plugin=cachepolicy.so @pparam=match-suffix-status=*:4XX|5XX:0 @plugin=background_fetch.so": 1,
//     "map http://heartbeat.cmcc http://heartbeat.cmcc @plugin=tslua.so @pparam=/etc/trafficserver/lua/heartbeat.lua": 1,
//     "map http://heartbeat.zy http://heartbeat.zy @plugin=tslua.so @pparam=/etc/trafficserver/lua/heartbeat.lua": 1,
//     "map http://hlsmgsplive.miguvideo.com http://hlsmgsplive.miguvideo.com @plugin=resolv.so @pparam=39.134.120.203:8080 @plugin=tslua.so @pparam=/etc/trafficserver/lua/new_live_cache_key.lua @pparam=hlsmgsplive.miguvideo.com:8080 @plugin=no_cache_status.so @pparam=403,416,503,302,502 @plugin=background_fetch.so @plugin=header_rewrite.so @pparam=/etc/trafficserver/plugins/headerrewrite/live.cache.cmvideo.cn.hr": 1,
//     "map http://hlsmgspvod.miguvideo.com http://hlsmgspvod.miguvideo.com @plugin=resolv.so @pparam=39.134.120.203:8080 @plugin=background_fetch.so @plugin=no_cache_status.so @pparam=403,404,416,503,302,502 @plugin=tslua.so @pparam=/etc/trafficserver/lua/no_range_cache_key.lua @pparam=hlsmgspvod.miguvideo.com:8080 @plugin=header_rewrite.so @pparam=/etc/trafficserver/plugins/headerrewrite/vod.cache.cmvideo.cn.hr": 1,
//     "map http://live.gj.miguvideo.com http://live.gj.miguvideo.com @plugin=tslua.so @pparam=/etc/trafficserver/lua/new_live_cache_key.lua @pparam=live.cache.cmvideo.cn:8088 @plugin=background_fetch.so": 1,
//     "map http://wx.sd.chinamobile.com http://wx.sd.chinamobile.com @plugin=resolv.so @pparam=223.99.141.11:80 @plugin=conf_remap.so @pparam=proxy.config.http.cache.required_headers=2 @plugin=cachepolicy.so @pparam=match-suffix-status=js|css|png|jpg|gif|swf:200|304:1d,*:*:0 @plugin=background_fetch.so": 1,
//     "map http://yy.migu.cmvideo.cn http://yy.migu.cmvideo.cn @plugin=tslua.so @pparam=/etc/trafficserver/lua/new_live_cache_key.lua @pparam=live.cache.cmvideo.cn:8088 @plugin=no_cache_status.so @pparam=403,404,416,503,302,502 @plugin=background_fetch.so": 1
// }

//L2
// ggc.cmvideo.cn
// hcdnservice.hn.chinamobiledevice.com ??
// scoreb-m.miguvideo.com
// upgrade.itv.cmvideo.cn
