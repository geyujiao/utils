package accesswrite

import "testing"

func TestGetLuaADomain(t *testing.T) {
	GetLuaADomain("./result copy/accessL1.txt", "./accessL1.txt")

}
