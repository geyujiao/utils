package toutils

import (
	"fmt"
	"testing"
)

func TestXxx(t *testing.T) {

	filePath := "example.txt" // 替换为你需要计算MD5的文件路径
	md5Value, err := Md5File(filePath)
	if err != nil {
		fmt.Println("Error:", err)
		return
	}
	fmt.Printf("MD5 of %s: %s\n", filePath, md5Value)
}
